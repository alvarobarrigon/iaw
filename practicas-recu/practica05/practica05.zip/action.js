$(function (e) {
    let numero = aleatorio(1,1000)
    let i=0
    let iTotal=0
    let partidas=0
    console.log(numero)
        $("#comprobar").on("click", (e) => {
            e.preventDefault()
            iTotal = parseInt(i) + 1
            console.log(iTotal)
            if ($("#number").val() > numero) {
                i++
                $("#fallo").html(
                    "<p>¡¡Fallaste!!</p>" +
                    "<p>Mi numero es menor</p>" +
                    "<p>Intentos: " + i + "</p>"
                )
            } else if ($("#number").val() < numero) {
                i++
                $("#fallo").html(
                    "<p>¡¡Fallaste!!</p>" +
                    "<p>Mi numero es mayor</p>" +
                    "<p>Intentos: " + i + "</p>"
                )
            } else {
                $(".normal").css("display", "none")
                $(".bt2").css("display", "block")
                i++
                partidas++
                $("#acierto").html(
                    "<div class='cancelado'>" +
                    "<h1>¡¡Has Acertado!!</h1>" +
                    "<p>Intentos: " + i + "</p>" +
                    "</div>"
                )
                $("#volver").on("click", (e) => {
                    e.preventDefault()
                    $("small").html(partidas)
                })
            }
        })
        $("#dejar").on("click", (e) => {
            e.preventDefault()
            $(".cancelado,.bt2").css("display", "none")
            if (partidas >= 1) {
                $(".dejar").css("display", "block").append(
                    "<p>Partidas jugadas: " + partidas + "</p>" +
                    "<p>Intentos por partidas: " + iTotal / partidas + "</p>"
                )
            } else {
                $(".dejar").css("display", "block")
            }

        })
        $("#cancelar").on("click", (e) => {
            e.preventDefault()
            $(".normal").css("display", "none")
            $(".cancelado,.bt2").css("display", "block")
        })
        $("#number").on("focus", (e) => {
            $("#fallo").html(" ")
        })

})